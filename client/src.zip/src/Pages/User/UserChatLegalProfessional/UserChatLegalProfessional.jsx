import React,{useState} from 'react';
import './UserChatLegalProfessional.css';

function UserChatLegalProfessional() {
  return (
    <div className='container-fluid'>
        
    </div>
  )
}

export default UserChatLegalProfessional